USE controlAsistencia;
GO

CREATE TABLE Usuarios (
    id_usuario INT IDENTITY(1,1) PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    apellido VARCHAR(50) NOT NULL,
    correo VARCHAR(100) NOT NULL UNIQU,
    clave VARCHAR(100) NOT NULL,
    rol VARCHAR(10) NOT NULL
);

CREATE TABLE Asistencia (
    id_asistencia INT IDENTITY(1,1) PRIMARY KEY,
    id_usuario INT NOT NULL,
    fecha DATE NOT NULL,
    hora_entrada TIME NULL,
    hora_salida TIME NULL,

    CONSTRAINT FK_Asistencia_Usuarios
    FOREIGN KEY (id_usuario)
    REFERENCES Usuarios(id_usuario)
);
GO
USE controlAsistencia;
GO

-- 1. Insertar los usuarios
INSERT INTO Usuarios (nombre, apellido, correo, clave, rol)
VALUES 
('Catalina', 'Painen', 'admin@correo.com', '1234', 'ADMIN'),       -- id_usuario = 1
('Juan', 'Pérez', 'juan.perez@correo.com', '1234', 'TRABAJADOR'),   -- id_usuario = 2
('María', 'González', 'maria.g@correo.com', '5678', 'TRABAJADOR');   -- id_usuario = 3
GO

-- 2. Insertar registros de asistencia de prueba
INSERT INTO Asistencia (id_usuario, fecha, hora_entrada, hora_salida)
VALUES 
(1, '2026-08-20', '08:30:00', '17:30:00'),
(1, '2026-08-21', '08:25:00', NULL),
(2, '2026-08-20', '08:45:00', '18:00:00');
GO

-- 3. Consultar con el JOIN correcto
SELECT 
    u.id_usuario,
    CONCAT(u.nombre, ' ', u.apellido) AS usuario,
    u.correo,
    u.rol,
    a.fecha,
    a.hora_entrada,
    a.hora_salida
FROM Usuarios u
LEFT JOIN Asistencia a ON u.id_usuario = a.id_usuario;

CREATE TABLE Retrasos (
    id_retraso INT IDENTITY(1,1) PRIMARY KEY,
    id_asistencia INT NOT NULL,
    hora_entrada TIME NOT NULL,
    minutos_retraso INT NOT NULL,

    CONSTRAINT FK_Retrasos_Asistencia
    FOREIGN KEY (id_asistencia)
    REFERENCES Asistencia(id_asistencia)
);

CREATE TABLE Salidas (
    id_salida INT IDENTITY(1,1) PRIMARY KEY,
    id_asistencia INT NOT NULL,
    hora_salida TIME NOT NULL,
    minutos_adelantados INT NOT NULL,

    CONSTRAINT FK_Salidas_Asistencia
    FOREIGN KEY (id_asistencia)
    REFERENCES Asistencia(id_asistencia)
);

CREATE TABLE Inasistencias (
    id_inasistencia INT IDENTITY(1,1) PRIMARY KEY,
    id_usuario INT NOT NULL,
    fecha DATE NOT NULL,
    motivo VARCHAR(50) NULL,

    CONSTRAINT FK_Inasistencias_Usuarios
    FOREIGN KEY (id_usuario)
    REFERENCES Usuarios(id_usuario)
);