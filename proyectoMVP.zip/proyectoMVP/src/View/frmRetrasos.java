
package View;

import Model.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

public class frmRetrasos extends javax.swing.JFrame {

    /**
     * Creates new form frmRetrasos
     */
    public frmRetrasos() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setSize(650, 400);
        
        this.setDefaultCloseOperation(
            javax.swing.WindowConstants.DISPOSE_ON_CLOSE
        );
        
        cargarRetrasos();
    }
    
    private void cargarRetrasos() {

      DefaultTableModel modelo = new DefaultTableModel();

      modelo.addColumn("Trabajador");
      modelo.addColumn("Fecha");
      modelo.addColumn("Hora entrada");
      modelo.addColumn("Minutos retraso");

      Conexion conectarse = new Conexion();
      Connection conexion = conectarse.getConexion();

      String sql =
            "SELECT "
            + "CONCAT(u.nombre, ' ', u.apellido) AS trabajador, "
            + "a.fecha, "
            + "r.hora_entrada, "
            + "r.minutos_retraso "
            + "FROM Retrasos r "
            + "INNER JOIN Asistencia a "
            + "ON r.id_asistencia = a.id_asistencia "
            + "INNER JOIN Usuarios u "
            + "ON a.id_usuario = u.id_usuario "
            + "ORDER BY a.fecha DESC";

     try {

          PreparedStatement consulta =
                conexion.prepareStatement(sql);

          ResultSet resultado =
                consulta.executeQuery();

          while (resultado.next()) {

              Object[] fila = new Object[4];

              fila[0] = resultado.getString("trabajador");
              fila[1] = resultado.getDate("fecha");
              fila[2] = resultado.getTime("hora_entrada");
              fila[3] = resultado.getInt("minutos_retraso");

              modelo.addRow(fila);
            }

          tblRetrasos.setModel(modelo);

        } catch (SQLException e) {

           System.out.println(
                "Error al cargar retrasos: "
                + e.getMessage()
            );
        }
    }
    
    
    


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblRetrasos = new javax.swing.JTable();
        btnVolver = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Reporte de Retrasos");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Retrasos"));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tblRetrasos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Trabajador", "Fecha", "Hora", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tblRetrasos);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, 460, 210));

        btnVolver.setText("Volver");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });
        jPanel1.add(btnVolver, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 290, 90, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 510, 340));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        
        this.dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmRetrasos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmRetrasos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmRetrasos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmRetrasos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmRetrasos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnVolver;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblRetrasos;
    // End of variables declaration//GEN-END:variables
}
