package Controller;

import Model.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Login {

    public ResultSet validarUsuario(String correo, String clave, String rol) throws SQLException {

        Conexion conectarse = new Conexion();
        Connection conexion = conectarse.getConexion();

        if (conexion == null) {
            return null;
        }

        // DEBES TENER LOS 3 '?' EN LA CONSULTA:
        String sql = "SELECT id_usuario, nombre, apellido, correo, rol FROM Usuarios WHERE correo = ? AND clave = ? AND rol = ?";

        PreparedStatement consultaLogin = conexion.prepareStatement(sql);
        
        consultaLogin.setString(1, correo);
        consultaLogin.setString(2, clave);
        consultaLogin.setString(3, rol); // <-- Aquí es donde daba error si faltaba el 3er '?'

        return consultaLogin.executeQuery();
    }
}