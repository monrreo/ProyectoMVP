package controller;

import Model.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import javax.swing.JOptionPane;

public class Crud {

    // Registra la entrada
    public boolean registrarEntrada(int idUsuario) {
        String sql = "INSERT INTO Asistencia (id_usuario, fecha, hora_entrada) VALUES (?, ?, ?)";
        Conexion conectarse = new Conexion();

        try (Connection con = conectarse.getConexion(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idUsuario);
            ps.setDate(2, java.sql.Date.valueOf(LocalDate.now()));
            ps.setTime(3, java.sql.Time.valueOf(LocalTime.now()));

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al registrar entrada: " + e.getMessage());
            return false;
        }
    }

    // Registra la salida
    public boolean registrarSalida(int idUsuario) {
        String sql = "UPDATE Asistencia SET hora_salida = ? "
                + "WHERE id_usuario = ? AND fecha = ? AND hora_salida IS NULL";

        Conexion conectarse = new Conexion();

        try (Connection con = conectarse.getConexion(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setTime(1, java.sql.Time.valueOf(LocalTime.now()));
            ps.setInt(2, idUsuario);
            ps.setDate(3, java.sql.Date.valueOf(LocalDate.now()));

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al registrar salida: " + e.getMessage());
            return false;
        }
    }

    // Registra un usuario
    public boolean guardarUsuario(String nombre, String apellido,
            String correo, String clave, String rol)
            throws SQLException {

        Conexion conectarse = new Conexion();

        try (Connection con = conectarse.getConexion()) {

            // Comprobamos si el correo ya existe
            String verificar = "SELECT id_usuario FROM Usuarios WHERE correo = ?";

            try (PreparedStatement psVerificar = con.prepareStatement(verificar)) {

                psVerificar.setString(1, correo);

                ResultSet resultado = psVerificar.executeQuery();

                if (resultado.next()) {
                    return false;
                }
            }

            // Si el correo no existe, guardamos el usuario
            String sql = "INSERT INTO Usuarios "
                    + "(nombre, apellido, correo, clave, rol) "
                    + "VALUES (?, ?, ?, ?, ?)";

            try (PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setString(1, nombre);
                ps.setString(2, apellido);
                ps.setString(3, correo);
                ps.setString(4, clave);
                ps.setString(5, rol);

                return ps.executeUpdate() > 0;
            }
        }
    }

    public ResultSet listarUsuarios() throws SQLException {

        String sql = "SELECT id_usuario, nombre, apellido, correo, rol "
                + "FROM Usuarios "
                + "ORDER BY id_usuario";

        Conexion conectarse = new Conexion();
        Connection con = conectarse.getConexion();

        PreparedStatement ps = con.prepareStatement(sql);

        return ps.executeQuery();
    }

    // Modificar usuarios
    
    public void modificarUsuario(int idUsuario, String nombre, String apellido,
            String correo, String clave, String rol) {

        String sql;

        if (clave.isEmpty()) {

            sql = "UPDATE Usuarios SET nombre=?, apellido=?, correo=?, rol=? "
                    + "WHERE id_usuario=?";

        } else {

            sql = "UPDATE Usuarios SET nombre=?, apellido=?, correo=?, clave=?, rol=? "
                    + "WHERE id_usuario=?";
        }

        Conexion conectarse = new Conexion();

        try (Connection con = conectarse.getConexion(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, nombre);
            ps.setString(2, apellido);
            ps.setString(3, correo);

            if (clave.isEmpty()) {

                ps.setString(4, rol);
                ps.setInt(5, idUsuario);

            } else {

                ps.setString(4, clave);
                ps.setString(5, rol);
                ps.setInt(6, idUsuario);
            }

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Usuario actualizado correctamente",
                    "Éxito",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(null,
                    "Error al modificar usuario: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    // Eliminar usuarios

    public void eliminarUsuario(int idUsuario) {

        String sql = "DELETE FROM Usuarios WHERE id_usuario=?";

        Conexion conectarse = new Conexion();

        try (Connection con = conectarse.getConexion(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idUsuario);

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Usuario eliminado correctamente",
                    "Éxito",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(null,
                    "Error al eliminar usuario: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
