package Controller;

import Model.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Duration;

public class Asistencia {

    public boolean registrarEntrada(int idUsuario) throws SQLException {

        Conexion conectarse = new Conexion();
        Connection conexion = conectarse.getConexion();

        if (conexion == null) {
            return false;
        }

        LocalDate fecha = LocalDate.now();
        LocalTime horaEntrada = LocalTime.now();

        // 1. Comprobar si el usuario ya tiene una entrada registrada hoy
        String verificar = "SELECT id_asistencia FROM Asistencia "
                + "WHERE id_usuario = ? AND fecha = ?";

        PreparedStatement consultaVerificar =
                conexion.prepareStatement(verificar);

        consultaVerificar.setInt(1, idUsuario);
        consultaVerificar.setDate(
                2,
                java.sql.Date.valueOf(fecha)
        );

        ResultSet resultadoVerificar =
                consultaVerificar.executeQuery();

        // Si ya existe una asistencia para hoy, no crea otra
        if (resultadoVerificar.next()) {

            return false;
        }

        // 2. Registrar la entrada
        String sql = "INSERT INTO Asistencia "
                + "(id_usuario, fecha, hora_entrada) "
                + "VALUES (?, ?, ?)";

        PreparedStatement consulta =
                conexion.prepareStatement(
                        sql,
                        PreparedStatement.RETURN_GENERATED_KEYS
                );

        consulta.setInt(1, idUsuario);
        consulta.setDate(
                2,
                java.sql.Date.valueOf(fecha)
        );
        consulta.setTime(
                3,
                java.sql.Time.valueOf(horaEntrada)
        );

        consulta.executeUpdate();

        // 3. Obtener el ID de la asistencia creada
        ResultSet resultado =
                consulta.getGeneratedKeys();

        if (resultado.next()) {

            int idAsistencia =
                    resultado.getInt(1);

            // 4. Comprobar si llegó atrasado
            LocalTime horaLimite =
                    LocalTime.of(9, 30);

            if (horaEntrada.isAfter(horaLimite)) {

                long minutosRetraso =
                        Duration.between(
                                horaLimite,
                                horaEntrada
                        ).toMinutes();

                // 5. Registrar el retraso
                String sqlRetraso =
                        "INSERT INTO Retrasos "
                        + "(id_asistencia, hora_entrada, minutos_retraso) "
                        + "VALUES (?, ?, ?)";

                PreparedStatement consultaRetraso =
                        conexion.prepareStatement(sqlRetraso);

                consultaRetraso.setInt(
                        1,
                        idAsistencia
                );

                consultaRetraso.setTime(
                        2,
                        java.sql.Time.valueOf(horaEntrada)
                );

                consultaRetraso.setInt(
                        3,
                        (int) minutosRetraso
                );

                consultaRetraso.executeUpdate();
            }

            return true;

        } else {

            return false;
        }
    }
    public boolean registrarSalida(int idUsuario) throws SQLException {

      Conexion conectarse = new Conexion();
      Connection conexion = conectarse.getConexion();

      if (conexion == null) {
         return false;
        }

      LocalDate fecha = LocalDate.now();
      LocalTime horaSalida = LocalTime.now();

      // Buscar la asistencia de hoy que todavía no tenga salida
      String buscar = "SELECT id_asistencia FROM Asistencia "
            + "WHERE id_usuario = ? "
            + "AND fecha = ? "
            + "AND hora_entrada IS NOT NULL "
            + "AND hora_salida IS NULL";

      PreparedStatement consultaBuscar =
             conexion.prepareStatement(buscar);

      consultaBuscar.setInt(1, idUsuario);

      consultaBuscar.setDate(
            2,
            java.sql.Date.valueOf(fecha)
        );

      ResultSet resultado =
             consultaBuscar.executeQuery();

      // Si no tiene entrada registrada, no puede marcar salida
      if (!resultado.next()) {
          return false;
        }

      int idAsistencia =
             resultado.getInt("id_asistencia");

      // Guardar hora de salida
      String actualizar =
             "UPDATE Asistencia "
             + "SET hora_salida = ? "
             + "WHERE id_asistencia = ?";

    PreparedStatement consultaActualizar =
            conexion.prepareStatement(actualizar);

    consultaActualizar.setTime(
            1,
            java.sql.Time.valueOf(horaSalida)
    );

    consultaActualizar.setInt(
            2,
            idAsistencia
    );

    int filas =
            consultaActualizar.executeUpdate();

    return filas > 0;
}
}