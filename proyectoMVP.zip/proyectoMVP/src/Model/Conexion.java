package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    public Connection getConexion() {

        String url = "jdbc:sqlserver://localhost:1433;"
                + "databaseName=controlAsistencia;"
                + "user=root;"
                + "password=root;"
                + "encrypt=true;"
                + "trustServerCertificate=true;";

        try {

            Connection con = DriverManager.getConnection(url);

            System.out.println("Conexión exitosa");

            return con;

        } catch (SQLException ex) {

            System.out.println(
                    "Error de conexión: "
                    + ex.getMessage()
            );

            return null;
        }
    }
}