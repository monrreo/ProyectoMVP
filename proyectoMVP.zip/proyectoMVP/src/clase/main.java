package clase;

import Model.Conexion;
import View.frmLogin;
import View.frmAdmin;
import javax.swing.UIManager;
import java.sql.Connection;

public class main {

    public static void main(String[] args) {

        Conexion conexion = new Conexion();

        Connection con = conexion.getConexion();

        if (con != null) {
            System.out.println("¡¡¡SQL SERVER CONECTADO!!!");
        }
        try {
            /* * UIManager: Configura el "Look and Feel" (apariencia visual).
         * getSystemLookAndFeelClassName() hace que la aplicación de Java 
         * tome el aspecto visual del sistema operativo donde se ejecute 
         * (ej: se verá como Windows 10/11 en lugar del diseño gris de Java).
             */
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            // En caso de que el diseño visual falle, imprimimos el error en consola
            e.printStackTrace();
        }
        
         frmLogin objMenu = new frmLogin();
        objMenu.setVisible(true);
    }
    
   
}
